import java.util.Scanner;
public class oppgaveO3 {
    public static void main(String args[]) {
         Scanner in = new Scanner(System.in);
         System.out.print("Skriv eit tal større enn 0: ");
         int n  = in.nextInt();
         int svar = 1;
         
         for (int i = 1; i <= n; i++) {
             svar *= i;
         }
             
   
   
   System.out.print(svar);
   
   in.close();
    }
}
   
   