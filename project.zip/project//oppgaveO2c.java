import java.util.Scanner;
public class oppgaveO2c {
    public static void main(String args[]) {
         Scanner in = new Scanner(System.in);
        
    int i;    
         
    for (i =0; i < 10; i++) {    
        	
        	System.out.print("skriv inn poengsum:");
         int Karakter  = in.nextInt();
        if(Karakter <= 100 && Karakter >= 90) {
		    
		    System.out.println("Karakteren er: A" );
		    
		
		    
		}else if(Karakter <= 89 && Karakter >=  80){
		    
		    System.out.println("Karakteren er B" );
		
		}else if(Karakter <=  79 && Karakter >= 60){
		    
		    System.out.println("Karakteren er C" );
		
		}else if(Karakter <= 59 && Karakter >= 50){
		    
		    System.out.println("Karakteren er D" );
		    
		}else if(Karakter <= 49 && Karakter >= 40){
		    
		    System.out.println("Karakteren er E");
		}else if(Karakter <= 39 && Karakter >= 0){
		    System.out.println("  Karakteren er F");
        }else{
             i = i - 1 ;
              System.out.println("ugyldig verdi");
             
            
        }
		
     }
	 in.close();
     }	
    }