import java.util.Scanner;
public class MyClass {
    public static void main(String args[]) {
        Scanner in = new Scanner(System.in);
        	System.out.print("pengar lønn:");
		double Lon  = in.nextInt();
		
		if(Lon >= 217410 && Lon <= 306050) {
		    Lon = Lon * 0.017;
		    System.out.println("Du må betale" + Lon );
		    
		
		    
		}else if(Lon >= 306050 && Lon <=  697150){
		    Lon = Lon * 0.04;
		    System.out.println("Du må betale" + Lon );
		
		}else if(Lon >=  697150 && Lon<= 942400){
		    Lon = Lon * 0.137;
		    System.out.println("Du må betale" + Lon );
		
		}else if(Lon >= 942400 && Lon <= 1410750){
		    Lon = Lon * 0.167;
		    System.out.println("Du må betale" + Lon );
		    
		}else if(Lon > 1410750 ){
		    Lon = Lon * 0.177;
		    System.out.println("Du må betale" + Lon );
		}else{
		    System.out.println("Du treng ikkje betale trinskatt!");
		}
		in.close();
		
		    
		    
		
    
    
    
   
    }
}
